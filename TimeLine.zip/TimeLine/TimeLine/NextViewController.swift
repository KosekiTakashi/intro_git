//
//  NextViewController.swift
//  TimeLine
//
//  Created by 小関隆司 on 2019/10/07.
//  Copyright © 2019 kosekitakashi. All rights reserved.
//

import UIKit
import Firebase

class NextViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    

    @IBOutlet weak var timeLineTableView: UITableView!
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    
    var userName = String()
    var titleName = String()
    var contentsArray = [Contents]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        timeLineTableView.delegate = self
        timeLineTableView.dataSource = self
        
        if UserDefaults.standard.object(forKey: "userName") != nil{
            userName = UserDefaults.standard.object(forKey: "userName") as! String
        }

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contentsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = timeLineTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let userName = cell.viewWithTag(1) as! UILabel
        userName.text = contentsArray[indexPath.row].userNameString
        
        let titleName = cell.viewWithTag(2) as! UILabel
        titleName.text = contentsArray[indexPath.row].titleNameString
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 215
    }
    
    
    @IBAction func add(_ sender: Any) {
        
        let addVC = storyboard?.instantiateViewController(identifier: "add") as! AddViewController
        
        self.navigationController?.pushViewController(addVC, animated: true)
    }
    
    
    func fetchData(){
        let ref = Database.database().reference().child("timeLine").queryLimited(toLast: 20).queryOrdered(byChild: "postDate").observe(.value) { (snapShot) in
            
            
            self.contentsArray.removeAll()
            
            if let snapShot = snapShot.children.allObjects as? [DataSnapshot]{
                
                for snap in snapShot{
                    
                    if let postData = snap.value as? [String:Any]{
                        
                        let userName = postData["userName"] as? String
                        let titleName = postData["titleName"] as? String
                        var postDate:CLong?
                        
                        if let postedDate = postData["postData"] as? CLong{
                            postDate = postedDate
                        }
                        
                       
                        
                        self.contentsArray.append(Contents.init(userName: userName!, titleName: titleName!))
                    }
                }
            }
            
            self.timeLineTableView.reloadData()
            
            let indexPath = IndexPath(row: self.contentsArray.count - 1, section: 0)
            if self.contentsArray.count >= 5{
                self.timeLineTableView.scrollToRow(at: indexPath , at: .bottom, animated: true)
            }
        }
    }
    
    
    //postDateを時間に変換する
    func convertTimeStamp(serverTimeStamp:CLong)->String{
        
        let x = serverTimeStamp / 1000
        let date = Date(timeIntervalSince1970: TimeInterval(x))
        let formattar = DateFormatter()
        formattar.dateStyle = .long
        formattar.timeStyle = .medium
        
        return formattar.string(from: date)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
