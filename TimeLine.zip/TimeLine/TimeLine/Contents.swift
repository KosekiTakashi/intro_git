//
//  Contents.swift
//  TimeLine
//
//  Created by 小関隆司 on 2019/10/07.
//  Copyright © 2019 kosekitakashi. All rights reserved.
//

import Foundation

class Contents {
    var userNameString:String = ""
    var titleNameString = ""
    
    init(userName:String,titleName:String) {
        self.userNameString = userName
        self.titleNameString = titleName
    }
}
