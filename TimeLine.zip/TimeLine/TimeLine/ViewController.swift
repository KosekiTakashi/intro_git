//
//  ViewController.swift
//  TimeLine
//
//  Created by 小関隆司 on 2019/10/07.
//  Copyright © 2019 kosekitakashi. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var userNameTextField: UITextField!
    
    var name : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameTextField.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func done(_ sender: Any) {
        UserDefaults.standard.set(name, forKey: "userName")
        let nextVC = self.storyboard?.instantiateViewController(identifier: "nextVC") as! NextViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        name = userNameTextField.text!
        
        userNameTextField.resignFirstResponder()
    }
    


}

