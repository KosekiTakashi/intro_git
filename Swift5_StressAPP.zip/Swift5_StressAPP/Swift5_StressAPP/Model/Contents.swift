//
//  Contents.swift
//  Swift5_StressAPP
//
//  Created by 小関隆司 on 2019/10/09.
//  Copyright © 2019 kosekitakashi. All rights reserved.
//

import Foundation

class Contents {
    var userNameString:String = ""
    var titleNameString:String = ""
    
    init(userName:String,titleName:String) {
        self.userNameString = userName
        self.titleNameString = titleName
    }
}
